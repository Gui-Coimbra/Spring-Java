package school.sptech.primeiaapi;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/pokemon")
public class PokemonController {

    private List<String> pokemon = new ArrayList<>();

    @GetMapping
    public String getQtd(){
        return "Total de pokemon cadastrados: " + pokemon.size();
    }

    @GetMapping("/cadastrar/{nome}")
    public String cadastrar(@PathVariable String nome){
        pokemon.add(nome);
        return "pokemon adicionado!";
    }

    @GetMapping("/recuperar/{indice}")
    public String recuperar(@PathVariable int indice){
        if (indice >= pokemon.size() || indice < 0){
            return "Pokemon não encontrado";
        }else {
            return "Pokemon: " + pokemon.get(indice);
        }
    }

    @GetMapping("/excluir/{indice}")
    public String excluir(@PathVariable int indice){
        if (indice >= pokemon.size() || indice < 0){
            return "Pokemon não encontrado";
        }else {
            pokemon.remove(indice);
            return "Excluído";
        }
    }

    @GetMapping("/atualizar/{indice}/{nome}")
    public String atualizar(@PathVariable int indice, @PathVariable String nome){
        if (indice >= pokemon.size() || indice < 0){
            return "Pokemon não encontrado";
        }else {
            pokemon.set(indice, nome);
            return "Pokemon atualizado";
        }
    }

}
