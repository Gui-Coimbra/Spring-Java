package school.sptech.primeiaapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrimeiaApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrimeiaApiApplication.class, args);
	}

}
