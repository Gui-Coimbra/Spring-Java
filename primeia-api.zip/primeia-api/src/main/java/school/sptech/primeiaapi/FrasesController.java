package school.sptech.primeiaapi;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//@Controller serve para servir paginas
@RestController // converte essa classe para uma controladora
@RequestMapping("/frases") // define um padrão de URI para a controller
public class FrasesController {

    @GetMapping // trasnforma o metodo em um endpoint (GET)
    public String hello(){
        return "Olá Mundo!";
    }

    @GetMapping("/bom-dia")
    public String bomDia(){
        return "Bom dia flor do dia";
    }

    @GetMapping("/boa-tarde")
    public String boaTarde(){
        return "Café??? ";
    }

    @GetMapping("/boa-noite")
    public String boaNoite(){
        return "Good night meninas";
    }

}
