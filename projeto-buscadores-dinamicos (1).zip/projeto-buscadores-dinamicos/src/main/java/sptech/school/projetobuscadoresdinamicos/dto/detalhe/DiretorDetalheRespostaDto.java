package sptech.school.projetobuscadoresdinamicos.dto.detalhe;

import io.swagger.v3.oas.annotations.media.Schema;
import sptech.school.projetobuscadoresdinamicos.dto.resumo.FilmeResumoRespostaDto;

import java.util.List;

public class DiretorDetalheRespostaDto {

    @Schema(description = "identificador", example = "1")
    private long id;
    @Schema(description = "nome do diretor(a)", example = "James Cameron")
    private String nome;

    private List<FilmeResumoRespostaDto> filmes;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public List<FilmeResumoRespostaDto> getFilmes() {
        return filmes;
    }

    public void setFilmes(List<FilmeResumoRespostaDto> filmes) {
        this.filmes = filmes;
    }
}
