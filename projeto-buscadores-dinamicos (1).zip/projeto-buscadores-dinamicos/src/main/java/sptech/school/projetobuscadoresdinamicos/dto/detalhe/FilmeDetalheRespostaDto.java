package sptech.school.projetobuscadoresdinamicos.dto.detalhe;

import sptech.school.projetobuscadoresdinamicos.domain.Diretor;
import sptech.school.projetobuscadoresdinamicos.dto.resumo.DiretorResumoDto;

import java.time.LocalDate;

public class FilmeDetalheRespostaDto {

    private Long id;

    private String nome;

    private DiretorResumoDto diretor;

    private LocalDate dataLancamento;

    private double custoProducao;

    private boolean indicacaoOscar;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public DiretorResumoDto getDiretor() {
        return diretor;
    }

    public void setDiretor(DiretorResumoDto diretor) {
        this.diretor = diretor;
    }

    public LocalDate getDataLancamento() {
        return dataLancamento;
    }

    public void setDataLancamento(LocalDate dataLancamento) {
        this.dataLancamento = dataLancamento;
    }

    public double getCustoProducao() {
        return custoProducao;
    }

    public void setCustoProducao(double custoProducao) {
        this.custoProducao = custoProducao;
    }

    public boolean isIndicacaoOscar() {
        return indicacaoOscar;
    }

    public void setIndicacaoOscar(boolean indicacaoOscar) {
        this.indicacaoOscar = indicacaoOscar;
    }
}
