package sptech.school.projetobuscadoresdinamicos.dto.mapper;

import sptech.school.projetobuscadoresdinamicos.domain.Filme;
import sptech.school.projetobuscadoresdinamicos.dto.detalhe.FilmeDetalheRespostaDto;
import sptech.school.projetobuscadoresdinamicos.dto.resumo.FilmeResumoRespostaDto;

import java.util.Objects;

public class FilmeMapper {

    private FilmeMapper() {
        throw new IllegalStateException("Classe utilitária");
    }

    public static FilmeResumoRespostaDto paraResumoDto(Filme dominio) {

        if (Objects.isNull(dominio)) {
            return null;
        }

        FilmeResumoRespostaDto dto = new FilmeResumoRespostaDto();

        dto.setId(dominio.getId());
        dto.setNome(dominio.getNome());
        dto.setNome(dominio.getNome());

        return dto;
    }

    public static FilmeDetalheRespostaDto paraDetalhesDto(Filme dominio) {

        if (Objects.isNull(dominio)) {
            return null;
        }

        FilmeDetalheRespostaDto dto = new FilmeDetalheRespostaDto();

        dto.setId(dominio.getId());
        dto.setNome(dominio.getNome());
        dto.setDataLancamento(dominio.getDataLancamento());
        dto.setCustoProducao(dominio.getCustoProducao());
        dto.setIndicacaoOscar(dominio.isIndicacaoOscar());

        dto.setDiretor(DiretorMapper.paraResumo(dominio.getDiretor()));

        return dto;
    }
}
