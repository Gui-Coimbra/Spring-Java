package sptech.school.projetobuscadoresdinamicos.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import sptech.school.projetobuscadoresdinamicos.domain.Diretor;

public interface DiretorRepository extends JpaRepository<Diretor, Long> {

}
