package sptech.school.projetobuscadoresdinamicos.controller;

import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import sptech.school.projetobuscadoresdinamicos.domain.Filme;
import sptech.school.projetobuscadoresdinamicos.dto.detalhe.FilmeDetalheRespostaDto;
import sptech.school.projetobuscadoresdinamicos.dto.mapper.FilmeMapper;
import sptech.school.projetobuscadoresdinamicos.dto.resumo.FilmeResumoRespostaDto;
import sptech.school.projetobuscadoresdinamicos.repository.FilmeRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Tag(name = "Filmes", description = "Requisicoes relacionadas a filmes")
@RestController
@RequestMapping("/filmes")
public class FilmeController {

    @Autowired
    private FilmeRepository filmeRepository;

    @PostMapping
    public ResponseEntity<FilmeResumoRespostaDto> cadastrar(@RequestBody Filme filme) {
        Filme filmeRegistrado = this.filmeRepository.save(filme);
        return ResponseEntity.status(201).body(FilmeMapper.paraResumoDto(filmeRegistrado));
    }

    @GetMapping
    public ResponseEntity<List<FilmeResumoRespostaDto>> listar() {

        List<Filme> filmes = this.filmeRepository.findAll();

        if (filmes.isEmpty()) {
            return ResponseEntity.status(204).build();
        }

        List<FilmeResumoRespostaDto> filmesDtos = filmes.stream()
                .map(FilmeMapper::paraResumoDto)
                .toList();

        return ResponseEntity.status(200).body(filmesDtos);
    }

    @GetMapping("/detalhes")
    public ResponseEntity<List<FilmeDetalheRespostaDto>> filmeDiretores() {

        List<Filme> filmes = this.filmeRepository.findAll();

        if (filmes.isEmpty()) {
            return ResponseEntity.status(204).build();
        }

        List<FilmeDetalheRespostaDto> filmesDtos = filmes.stream()
                .map(FilmeMapper::paraDetalhesDto)
                .toList();

        return ResponseEntity.status(200).body(filmesDtos);
    }

    @GetMapping("/{id}")
    public ResponseEntity<FilmeResumoRespostaDto> buscarPorId(@PathVariable long id) {

        Optional<Filme> filmeOptional = this.filmeRepository.findById(id);

        if (filmeOptional.isPresent()) {
            return ResponseEntity.status(200).body(FilmeMapper.paraResumoDto(filmeOptional.get()));
        }

        return ResponseEntity.status(404).build();
    }

    @GetMapping("/titulo")
    public ResponseEntity<FilmeResumoRespostaDto> buscarPorNome
            (@RequestParam String nome) {

        Optional<Filme> filmeOptional = this.filmeRepository.findByNome(nome);

        if (filmeOptional.isPresent()) {
            return ResponseEntity.status(200).body(FilmeMapper.paraResumoDto(filmeOptional.get()));
        }

        return ResponseEntity.status(404).build();
    }

    @GetMapping("/diretor")
    public ResponseEntity<List<FilmeResumoRespostaDto>> buscarPorDiretor(
            @RequestParam String nome) {

        List<Filme> filmesFiltrados = this.filmeRepository.findByDiretorNomeIgnoreCase(nome);

        if (filmesFiltrados.isEmpty()) {
            return ResponseEntity.status(204).build();
        }

        List<FilmeResumoRespostaDto> filmesDtos = filmesFiltrados.stream()
                .map(FilmeMapper::paraResumoDto)
                .toList();

        return ResponseEntity.status(200).body(filmesDtos);

    }

    @GetMapping("/periodo/{data}")
    public ResponseEntity<List<FilmeResumoRespostaDto>> buscarPorDiretor(@PathVariable LocalDate data) {

        List<Filme> filmesFiltrados = this.filmeRepository.findByDataLancamentoLessThanEqual(data);

        if (filmesFiltrados.isEmpty()) {
            return ResponseEntity.status(204).build();
        }

        List<FilmeResumoRespostaDto> filmesDtos = filmesFiltrados.stream()
                .map(FilmeMapper::paraResumoDto)
                .toList();

        return ResponseEntity.status(200).body(filmesDtos);
    }

    @GetMapping("/indicados")
    public ResponseEntity<List<FilmeResumoRespostaDto>> buscarSomenteIndicados() {

        List<Filme> filmesFiltrados = this.filmeRepository.findByIndicacaoOscarTrue();

        if (filmesFiltrados.isEmpty()) {
            return ResponseEntity.status(204).build();
        }

        List<FilmeResumoRespostaDto> filmesDtos = filmesFiltrados.stream()
                .map(FilmeMapper::paraResumoDto)
                .toList();

        return ResponseEntity.status(200).body(filmesDtos);
    }

    @GetMapping("/nao-indicados/quantidade")
    public ResponseEntity<Integer> contarSomenteNaoIndicados() {
        int contador = this.filmeRepository.countByIndicacaoOscarFalse();
        return ResponseEntity.status(200).body(contador);
    }

    @GetMapping("/custo-producao/{custo}")
    public ResponseEntity<List<FilmeResumoRespostaDto>> buscarFilmesComCustoAlto(@PathVariable double custo) {

        List<Filme> filmesFiltrados = this.filmeRepository.findByCustoProducaoGreaterThan(custo);

        if (filmesFiltrados.isEmpty()) {
            return ResponseEntity.status(204).build();
        }

        List<FilmeResumoRespostaDto> filmesDtos = filmesFiltrados.stream()
                .map(FilmeMapper::paraResumoDto)
                .toList();

        return ResponseEntity.status(200).body(filmesDtos);

    }
}
