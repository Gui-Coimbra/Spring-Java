package sptech.school.projetobuscadoresdinamicos.dto.mapper;

import sptech.school.projetobuscadoresdinamicos.domain.Diretor;
import sptech.school.projetobuscadoresdinamicos.dto.detalhe.DiretorDetalheRespostaDto;
import sptech.school.projetobuscadoresdinamicos.dto.resumo.DiretorResumoDto;
import sptech.school.projetobuscadoresdinamicos.dto.resumo.FilmeResumoRespostaDto;

import java.util.List;
import java.util.Objects;

public class DiretorMapper {

    private DiretorMapper() {
        throw new IllegalStateException("Classe utilitária");
    }

    public static DiretorDetalheRespostaDto paraDetalhesDto(Diretor dominio) {

        if (Objects.isNull(dominio)) {
            return null;
        }

        DiretorDetalheRespostaDto dto = new DiretorDetalheRespostaDto();

        dto.setId(dominio.getId());
        dto.setNome(dominio.getNome());

        List<FilmeResumoRespostaDto> filmesDto = dominio.getFilmes().stream()
                .map(FilmeMapper::paraResumoDto)
                .toList();

        dto.setFilmes(filmesDto);

        return dto;
    }

    public static DiretorResumoDto paraResumo(Diretor dominio) {

        if (Objects.isNull(dominio)) {
            return null;
        }

        DiretorResumoDto dto = new DiretorResumoDto();

        dto.setId(dominio.getId());
        dto.setNome(dominio.getNome());

        return dto;
    }
}
