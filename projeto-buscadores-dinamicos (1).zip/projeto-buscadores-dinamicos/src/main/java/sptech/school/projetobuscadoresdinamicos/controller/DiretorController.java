package sptech.school.projetobuscadoresdinamicos.controller;

import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import sptech.school.projetobuscadoresdinamicos.domain.Diretor;
import sptech.school.projetobuscadoresdinamicos.dto.detalhe.DiretorDetalheRespostaDto;
import sptech.school.projetobuscadoresdinamicos.dto.mapper.DiretorMapper;
import sptech.school.projetobuscadoresdinamicos.repository.DiretorRepository;

import java.util.List;

@Tag(name = "Diretores(as)", description = "Requisicoes relacionadas a diretores(as)")
@RestController
@RequestMapping("/diretores")
public class DiretorController {

    @Autowired
    private DiretorRepository diretorRepository;

    @GetMapping
    @ApiResponse(responseCode = "204", description =
            "Não há diretores(as) cadastrados.", content = @Content(schema = @Schema(hidden = true)))
    @ApiResponse(responseCode = "200", description = "diretores(as) encontrados.")
    public ResponseEntity<List<DiretorDetalheRespostaDto>> listar(){
        List<Diretor> diretores = this.diretorRepository.findAll();

        if (diretores.isEmpty()){
            return ResponseEntity.status(204).build();
        }

        List<DiretorDetalheRespostaDto> diretoresDto = diretores.stream()
                .map(DiretorMapper::paraDetalhesDto)
                .toList();

        return ResponseEntity.status(200).body(diretoresDto);
    }
}
