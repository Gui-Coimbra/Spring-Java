package sptech.school.projetobuscadoresdinamicos.dto.resumo;

import io.swagger.v3.oas.annotations.media.Schema;

public class FilmeResumoRespostaDto {

    @Schema(description = "identificador", example = "1")
    private long id;

    @Schema(description = "nome do filme", example = "Titanic")
    private String nome;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
