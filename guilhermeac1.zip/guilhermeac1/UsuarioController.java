package sptech.school.guilhermeac1;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("usuarios")
public class UsuarioController {

    List<Usuario> usuarios = new ArrayList<>();

    // a)
    @PostMapping
    public String cadastrar(@RequestBody Usuario user){
        if (user.getLogin().length() < 4 || user.getSenha().length() < 4 || user.getNome().length() < 7){
            return "login e senha precisam ter pelo menos 4 letras e o nome pelo menos 7";
        }else{
            for (Usuario u : usuarios){
                if (u.getLogin().equals(user.getLogin())){
                    return "O " + user.getLogin() + " já existe no sistema";
                }
            }
        }
        usuarios.add(user);
        return "Usuário " + user.getNome() + " cadastrado com sucesso";
    }

    // b)
    @DeleteMapping("/{login}")
    public String deletar(@PathVariable String login){
        for(Usuario u : usuarios){
            if(u.getLogin().equals(login)){
                u.setAtivo(false);
                u.setAutenticado(false);
                return "Usuário " + u.getLogin() + " desativado";
            }
        }
        return "Usuário " + login + " não encontrado";
    }

    // c)
    @GetMapping()
    public List<Usuario> listar(){
        return usuarios;
    }

    // d)
    @PostMapping("/autenticacao")
    public String autenticar(@RequestBody String login,
                             @RequestBody String senha){
        for(Usuario user : usuarios){
            if(user.getLogin().equals(login) && user.getSenha().equals(senha)){
                if(user.isAtivo()){
                    user.setAcessos(user.getAcessos()+1);
                    user.setAutenticado(true);
                    return "Usuário " + user.getLogin() + " autenticado com sucesso";
                }else{
                    return "Usuário " + user.getLogin() + " não está ativo";
                }
            }
        }
        return "Usuário " + login + " não encontrado";
    }

    // e)
    @DeleteMapping("/autenticacao/{login}")
    public String desautenticar(@PathVariable String login){
        for(Usuario user : usuarios){
            if(user.getLogin().equals(login)){
                user.setAutenticado(false);
                return "Usuário " + user.getLogin() + " fez logoff com sucesso";
            }
        }
        return "Usuário " + login + " não encontrado";
    }

    // f)
    @PatchMapping("/senha/{login}")
    public String alterar(@PathVariable String login,
                          @RequestBody String senha,
                          @RequestBody String dicaSenha){
        for(Usuario user : usuarios){
            if(user.getLogin().equals(login)){
                user.setSenha(senha);
                user.setDicaSenha(dicaSenha);
                return "Senha do usuário " + user.getLogin() + " alterada com sucesso";
            }
        }
        return "Usuário " + login + " não encontrado";
    }
}
