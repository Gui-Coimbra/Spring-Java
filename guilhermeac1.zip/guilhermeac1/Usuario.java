package sptech.school.guilhermeac1;

public class Usuario {

    private String login;
    private String senha;
    private String nome;
    private String dicaSenha;
    private boolean ativo;
    private boolean autenticado;
    private int acessos;

    public Usuario(String login, String senha, String nome, String dicaSenha, boolean ativo) {
        this.login = login;
        this.senha = senha;
        this.nome = nome;
        this.dicaSenha = dicaSenha;
        this.ativo = ativo;
        this.autenticado = false;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDicaSenha() {
        return dicaSenha;
    }

    public void setDicaSenha(String dicaSenha) {
        this.dicaSenha = dicaSenha;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

    public boolean isAutenticado() {
        return autenticado;
    }

    public void setAutenticado(boolean autenticado) {
        this.autenticado = autenticado;
    }

    public int getAcessos() {
        return acessos;
    }

    public void setAcessos(int acessos) {
        this.acessos = acessos;
    }
}
