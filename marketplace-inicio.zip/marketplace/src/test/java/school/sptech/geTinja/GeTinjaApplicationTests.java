package school.sptech.geTinja;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeTinjaApplicationTests {

	@Test
	void contextLoads() {
	}

}
