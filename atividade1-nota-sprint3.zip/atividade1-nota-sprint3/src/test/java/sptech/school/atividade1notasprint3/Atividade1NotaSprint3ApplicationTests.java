package sptech.school.atividade1notasprint3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Atividade1NotaSprint3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
