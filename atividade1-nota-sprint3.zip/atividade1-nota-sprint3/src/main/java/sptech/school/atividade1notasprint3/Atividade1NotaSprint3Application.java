package sptech.school.atividade1notasprint3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Atividade1NotaSprint3Application {

	public static void main(String[] args) {
		SpringApplication.run(Atividade1NotaSprint3Application.class, args);
	}

}
