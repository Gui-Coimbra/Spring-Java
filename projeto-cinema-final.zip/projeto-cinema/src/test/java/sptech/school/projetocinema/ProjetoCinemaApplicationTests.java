package sptech.school.projetocinema;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoCinemaApplicationTests {

	@Test
	void contextLoads() {
	}

}
