package school.sptech.responseentity;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/filmes")
public class FilmeController {

    private List<Filme> filmes = new ArrayList<>();

    private static final int ANO_LANCAMENTO_MINIMO = 1_895;

    @GetMapping
    public ResponseEntity<List<Filme>> listar() {
        if (filmes.isEmpty()) {
            return ResponseEntity.status(204).build();
        }

        return ResponseEntity.status(200).body(filmes);
    }

    @GetMapping("/{indice}")
    public ResponseEntity<Filme> buscarPorIndice(@PathVariable int indice) {
        if (isIndiceValido(indice)) {
            return ResponseEntity.status(200).body(filmes.get(indice));
        }

        return ResponseEntity.status(404).build();
    }

    @PostMapping
    public ResponseEntity<Filme> cadastrar(@RequestBody Filme filme) {
        if (isFilmeValido(filme)) {
            filmes.add(filme);
            return ResponseEntity.status(201).body(filme);
        }

        return ResponseEntity.status(400).build();
    }

    @PutMapping("/{indice}")
    public ResponseEntity<Filme> atualizar(@PathVariable int indice, @RequestBody Filme filme) {

        if (isIndiceValido(indice)) {

            if (isFilmeValido(filme)) {
                this.filmes.set(indice, filme);

                return ResponseEntity.status(200).body(filme);
            }

            return ResponseEntity.status(400).build();
        }

        return ResponseEntity.status(404).build();
    }

    @PatchMapping("/{indice}")
    public ResponseEntity<Filme> atualizarOscars(
            @PathVariable int indice,
            @RequestBody AtualizarOscarDto atualizarOscarDto
    ) {

        if (isIndiceValido(indice)) {

            Filme filme = this.filmes.get(indice);
            filme.setQtdOscar(atualizarOscarDto.getQuantidade());

            return ResponseEntity.status(200).body(filme);
        }

        return ResponseEntity.status(404).build();
    }

    //BÔNUS
    @DeleteMapping("/{indice}")
    public ResponseEntity<Void> remover(@PathVariable int indice) {
        if (isIndiceValido(indice)) {
            this.filmes.remove(indice);
            return ResponseEntity.status(200).build();
        }

        return ResponseEntity.status(404).build();
    }

    private boolean isIndiceValido(int indice) {
        return indice >= 0 && indice < filmes.size();
    }

    private boolean isFilmeValido(Filme filme) {

        String nome = filme.getNome();
        int anoLancamento = filme.getAnoLancamento();

        return isNomeValido(nome) && isAnoLancamentoValido(anoLancamento);
    }

    private boolean isNomeValido(String nome) {
        return nome.length() >= 2;
    }

    private boolean isAnoLancamentoValido(int ano) {
        return ano > ANO_LANCAMENTO_MINIMO;
    }
}
