package school.sptech.responseentity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResponseEntityApplicationTests {

	@Test
	void contextLoads() {
	}

}
