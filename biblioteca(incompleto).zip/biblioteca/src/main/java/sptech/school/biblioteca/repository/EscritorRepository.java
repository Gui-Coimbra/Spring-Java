package sptech.school.biblioteca.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import sptech.school.biblioteca.domain.Escritor;

public interface EscritorRepository extends JpaRepository<Escritor, Long> {
}
