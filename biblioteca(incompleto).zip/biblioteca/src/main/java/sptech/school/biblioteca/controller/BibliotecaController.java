package sptech.school.biblioteca.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import sptech.school.biblioteca.domain.Livro;
import sptech.school.biblioteca.repository.EscritorRepository;
import sptech.school.biblioteca.repository.LivroRepository;

import java.util.List;

@RestController
@RequestMapping("/biblioteca")
public class BibliotecaController {
    @Autowired
    private EscritorRepository escritorRepository;

    @Autowired
    private LivroRepository livroRepository;

    @GetMapping
    public static ResponseEntity<List<Livro>> listar(){

    }
}
