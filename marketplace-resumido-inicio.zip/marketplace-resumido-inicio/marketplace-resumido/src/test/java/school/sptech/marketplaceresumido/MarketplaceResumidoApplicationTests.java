package school.sptech.marketplaceresumido;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class MarketplaceResumidoApplicationTests {

	//@Test
	void contextLoads() {
	}

}
