INSERT INTO produto
    (nome, descricao, preco)
VALUES
    ('Iphone 11', 'Celular da Apple', 3500.00),
    ('Galaxy S20', 'Celular da Samsung', 3000.00),
    ('Moto G8', 'Celular da Motorola', 1500.00),
    ('Redmi Note 8', 'Celular da Xiaomi', 1200.00),
    ('Zenfone 6', 'Celular da Asus', 2000.00),
    ('LG K12', 'Celular da LG', 1000.00),
    ('Iphone 8', 'Celular da Apple', 2500.00),
    ('Galaxy S10', 'Celular da Samsung', 2000.00),
    ('Moto G7', 'Celular da Motorola', 1000.00),
    ('Redmi Note 7', 'Celular da Xiaomi', 900.00);
