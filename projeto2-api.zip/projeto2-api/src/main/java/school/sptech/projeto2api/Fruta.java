package school.sptech.projeto2api;

public class Fruta {

    private String nome;
    private double preco;
    private int quantidade;
    private boolean temSemente;

    public Fruta(String nome, double preco, int quantidade, boolean temSemente) {
        this.nome = nome;
        this.preco = preco;
        this.quantidade = quantidade;
        this.temSemente = temSemente;
    }

    public Fruta() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public boolean isTemSemente() {
        return temSemente;
    }

    public void setTemSemente(boolean temSemente) {
        this.temSemente = temSemente;
    }

    public String getPrecoDescricao(){
        return preco > 10 ? "Caro..." : "Ta no precinho";
    }
}
