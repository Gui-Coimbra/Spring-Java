package school.sptech.projeto2api;

public class FrutaSimplesDto {
    private String nome;
    private double preco;

    public FrutaSimplesDto(Fruta fruta) {
        this.nome = fruta.getNome();
        this.preco = fruta.getPreco();
    }
}
