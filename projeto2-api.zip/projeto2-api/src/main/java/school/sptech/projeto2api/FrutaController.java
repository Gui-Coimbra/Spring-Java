package school.sptech.projeto2api;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/frutas")
public class FrutaController {

    private List<Fruta> frutas = new ArrayList<>();

    @GetMapping("/favorita")
    public Fruta getFavorita(){
        return new Fruta("uva", 15.0, 20, false);
    }

    @GetMapping
    public List<Fruta> listar(){
        return frutas;
    }

    /*
    * /frutas/cadastrar/{nome}/{preco}/{quantidade}/{semente}
    * */

    @GetMapping("/cadastrar/{nome}/{preco}/{quantidade}/{semente}")
    public Fruta cadastrar(@PathVariable String nome,
                         @PathVariable double preco,
                         @PathVariable int quantidade,
                         @PathVariable boolean semente){

        Fruta fruta = new Fruta(nome, preco, quantidade, semente);
        frutas.add(fruta);

        return fruta;
    }

    /*
     * /frutas/recuperar/{indice}
     * */

    @GetMapping("/recuperar/{indice}")
    public Fruta recuperar(@PathVariable int indice){
        if(indice >= 0 && indice < frutas.size()){
            return frutas.get(indice);
        }else {
            return null;
        }
    }

    /*
     * /frutas/atualizar/{indice}/{nome}/{preco}/{quantidade}/{semente}
     * */

    @GetMapping("atualizar/{indice}/{nome}/{preco}/{quantidade}/{semente}")
    public Fruta atualizar(@PathVariable int indice,
                          @PathVariable String nome,
                          @PathVariable double preco,
                          @PathVariable int quantidade,
                          @PathVariable boolean semente){
        if(indice >= 0 && indice < frutas.size()){
            Fruta novaFruta = new Fruta(nome, preco, quantidade, semente);
            frutas.set(indice, novaFruta);
            return novaFruta;
        }else {
            return null;
        }
    }

    @GetMapping("/remover/{indice}")
    public String remover(@PathVariable int indice){
        if(indice >= 0 && indice < frutas.size()){
            frutas.remove(indice);
            return "Fruta removida";
        }else{
            return "Fruta não encontrada";
        }
    }
}
