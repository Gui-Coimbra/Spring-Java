package school.sptech.login02221070guilherme;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Usuario02221070GuilhermeApplicationTests {

	@Test
	void contextLoads() {
	}

}
