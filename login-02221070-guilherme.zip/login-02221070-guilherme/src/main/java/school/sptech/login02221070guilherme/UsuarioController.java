package school.sptech.login02221070guilherme;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    List<Usuario> usuarios = new ArrayList<>();
    @GetMapping
    public List<UsuarioSemSenha> listar(){
        List<UsuarioSemSenha> secretUsers = new ArrayList<>();
        for (Usuario user : usuarios){
            UsuarioSemSenha secretUser = new UsuarioSemSenha(user);
            secretUsers.add(secretUser);
        }
        return secretUsers;
    }

    @PostMapping()
    public UsuarioSemSenha cadastrar(@RequestBody Usuario user){
        usuarios.add(user);
        List<UsuarioSemSenha> secretUsers = new ArrayList<>();
        UsuarioSemSenha secretUser = new UsuarioSemSenha(user);
        secretUsers.add(secretUser);
        return secretUser;
    };

    @PostMapping("/autenticacao/{usuario}/{senha}")
    public UsuarioSemSenha autenticar(@PathVariable String usuario,
                               @PathVariable String senha){
        for (Usuario user : usuarios){
            if(user.getUsuario().equals(usuario) && user.getSenha().equals(senha)){
                user.setAutenticado(true);
                UsuarioSemSenha secretUser = new UsuarioSemSenha(user);
                return secretUser;
            }
        }
        return null;
    }

    @DeleteMapping("/autenticacao/{usuario}")
    public String deletar(@PathVariable String usuario){
        for (Usuario user : usuarios){
            if(user.getNome().equals(usuario)){
                if(user.isAutenticado() == true){
                    user.setAutenticado(false);
                    return "Logoff do usuário " + user.getNome() + " concluído";
                }else{
                    return "Usuário " + usuario + " NÃO está autenticado";
                }
            }
        }
        return "Usuário " + usuario + " não encontrado";
    }

    // O método que desenvolvi serve para atualizar a senha do usuário
    @PatchMapping("/atualizar/{usuario}/{senha}/{novaSenha}")
    public String atualizar(@PathVariable String usuario,
                            @PathVariable String senha,
                            @PathVariable String novaSenha){
        for(Usuario user : usuarios){
            if(user.getUsuario().equals(usuario)){
                if(user.getSenha().equals(senha)){
                    user.setSenha(novaSenha);
                    return "Senha do usuario " + user.getNome() + " alterada com sucesso!";
                }else{
                    return "Senha incorreta!";
                }
            }
        }
        return "Usuário " + usuario + " não encontrado";
    }
}
