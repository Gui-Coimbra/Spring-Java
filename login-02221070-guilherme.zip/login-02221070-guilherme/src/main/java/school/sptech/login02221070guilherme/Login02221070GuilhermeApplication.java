package school.sptech.login02221070guilherme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Login02221070GuilhermeApplication {

	public static void main(String[] args) {
		SpringApplication.run(Login02221070GuilhermeApplication.class, args);
	}

}
