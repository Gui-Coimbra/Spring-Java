package school.sptech.marketplaceresumido.service.calculadora;

import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
public class CalculadoraImpostoService {

    // IMPOSTO SOBRE CIRCULACAO DE MERCADORIAS E SERVICOS
    private final double ICMS = 0.18;

    public double calcularIcms(Double valorProduto) {

        if (Objects.isNull(valorProduto)) {
            throw new IllegalArgumentException("Valor do produto não pode ser nulo");
        }

        if (valorProduto < 0) {
            throw new IllegalArgumentException("Valor do produto não pode ser negativo");
        }

        if (valorProduto == 0) {
            throw new IllegalArgumentException("Valor do produto não pode ser zero");
        }

        return valorProduto * ICMS;
    }
}
