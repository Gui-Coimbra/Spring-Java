package school.sptech.marketplaceresumido.service.produto;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import school.sptech.marketplaceresumido.domain.Produto;
import school.sptech.marketplaceresumido.domain.data.ProdutoRepository;
import school.sptech.marketplaceresumido.domain.exception.EntidadeNaoEncontradaException;
import school.sptech.marketplaceresumido.service.produto.builder.ProdutoBuilder;
import school.sptech.marketplaceresumido.service.produto.dto.ProdutoAtualizacaoDto;
import school.sptech.marketplaceresumido.service.produto.dto.ProdutoConsultaDto;
import school.sptech.marketplaceresumido.service.produto.dto.ProdutoCriacaoDto;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class ProdutoServiceTest {

    @Mock
    private ProdutoRepository repository;

    @InjectMocks
    private ProdutoService produtoService;

    @Test
    @DisplayName("Deve retornar lista vazia quando nao houver produtos")
    void deveRetornarListaVaziaQuandoNaoHouverProdutos() {

        //given
        int quantidadeEsperada = 0;

        //when
        Mockito.when(repository.findAll()).thenReturn(new ArrayList<>());

        //then
        List<ProdutoConsultaDto> resultado = produtoService.listar();

        //assert
        assertTrue(resultado.isEmpty());
        assertEquals(quantidadeEsperada, resultado.size());
    }

    @Test
    @DisplayName("Deve retornar lista com tres itens quando houver tres itens cadastrados")
    void deveRetornarTresItensQuandoHouverTresItensCadastrados() {

        //given
        List<Produto> produtos = ProdutoBuilder.criarListaProduto();

        //when
        Mockito.when(repository.findAll()).thenReturn(produtos);

        //then
        List<ProdutoConsultaDto> resultado = produtoService.listar();

        //assert
        assertFalse(resultado.isEmpty());
        assertEquals(3, resultado.size());
    }

    @Test
    @DisplayName("Deve retornar produto quando buscar por id e existir produto com id informado")
    void deveRetornarProdutoQuandoBuscarPorIdEExistirProdutoComIdInformado() {

        //given
        Produto produto = ProdutoBuilder.criarProduto();

        //when
        Mockito.when(repository.findById(1L)).thenReturn(Optional.of(produto));

        //then
        ProdutoConsultaDto resultado = produtoService.buscarPorId(1L);

        //assert
        assertNotNull(resultado);
        assertEquals(produto.getId(), resultado.getId());
        assertEquals(produto.getNome(), resultado.getNome());
        assertEquals(produto.getDescricao(), resultado.getDescricao());
        assertEquals(produto.getPreco(), resultado.getPreco());
    }

    @Test
    @DisplayName("Deve retornar excecao quando buscar por id e nao existir produto com id informado")
    void deveRetornarExcecaoQuandoBuscarPorIdENaoExistirProdutoComIdInformado() {

        //given
        Long id = 1L;

        //when
        Mockito.when(repository.findById(id)).thenReturn(Optional.empty());

        //then
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            produtoService.buscarPorId(id);
        });

        //assert
        assertEquals("produto nao encontrado", exception.getMessage());
    }

    @Test
    @DisplayName("Deve criar produto quando informar dados validos")
    void deveCriarProdutoQuandoInformarDadosValidos() {

        //given
        Produto produto = ProdutoBuilder.criarProduto();
        ProdutoCriacaoDto produtoCriacaoDto = ProdutoBuilder.criarProdutoCriacaoDto();

        //when
        Mockito.when(repository.save(Mockito.any(Produto.class))).thenReturn(produto);

        //then
        ProdutoConsultaDto resultado = produtoService.criar(produtoCriacaoDto);

        //assert
        assertNotNull(resultado);
        assertEquals(produto.getId(), resultado.getId());
        assertEquals(produto.getNome(), resultado.getNome());
        assertEquals(produto.getDescricao(), resultado.getDescricao());
        assertEquals(produto.getPreco(), resultado.getPreco());
    }

    @Test
    @DisplayName("Deve atualizar produto quando informar dados validos")
    void deveAtualizarProdutoQuandoInformarDadosValidos() {

        //given
        Produto produto = ProdutoBuilder.criarProduto();
        ProdutoAtualizacaoDto produtoAtualizacaoDto = ProdutoBuilder.criarProdutoAtualizacaoDto();

        //when
        Mockito.when(repository.existsById(Mockito.anyLong())).thenReturn(true);
        Mockito.when(repository.save(Mockito.any(Produto.class))).thenReturn(produto);

        //then
        ProdutoConsultaDto resultado = produtoService.atualizar(1l, produtoAtualizacaoDto);

        //assert
        assertNotNull(resultado);
        assertEquals(produto.getId(), resultado.getId());
        assertEquals(produto.getNome(), resultado.getNome());
        assertEquals(produto.getDescricao(), resultado.getDescricao());
        assertEquals(produto.getPreco(), resultado.getPreco());

        Mockito.verify(repository, Mockito.times(1)).existsById(Mockito.anyLong());
        Mockito.verify(repository, Mockito.times(1)).save(Mockito.any(Produto.class));
    }

    @Test
    @DisplayName("Deve retornar excecao quando atualizar produto e nao existir produto com id informado")
    void deveRetornarExcecaoQuandoAtualizarProdutoENaoExistirProdutoComIdInformado() {

        //given
        Long id = 1L;
        ProdutoAtualizacaoDto produtoAtualizacaoDto = ProdutoBuilder.criarProdutoAtualizacaoDto();

        //when
        Mockito.when(repository.existsById(Mockito.anyLong())).thenReturn(false);

        //then
        EntidadeNaoEncontradaException exception = assertThrows(EntidadeNaoEncontradaException.class, () -> {
            produtoService.atualizar(id, produtoAtualizacaoDto);
        });

        //assert
        assertEquals("produto nao encontrado", exception.getMessage());
    }
}