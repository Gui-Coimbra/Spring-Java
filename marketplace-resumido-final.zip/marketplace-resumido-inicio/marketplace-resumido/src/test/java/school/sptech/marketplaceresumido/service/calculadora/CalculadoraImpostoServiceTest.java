package school.sptech.marketplaceresumido.service.calculadora;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CalculadoraImpostoServiceTest {

    @Test
    @DisplayName("Deve retornar corretamente o valor do ICMS quando o valor do produto for válido")
    void deveRetornarCorretamenteOValorDoIcmsQuandoOValorDoProdutoForValido() {

        CalculadoraImpostoService calculadoraImpostoService = new CalculadoraImpostoService();
        Double valorProduto = 100.0;

        Double valorIcms = calculadoraImpostoService.calcularIcms(valorProduto);

        assertEquals(18.0, valorIcms);
    }


    @Test
    @DisplayName("Deve lançar IllegalArgumentException quando o valor do produto for nulo")
    void deveLancarIllegalArgumentExceptionQuandoOValorDoProdutoForNulo() {

        CalculadoraImpostoService calculadoraImpostoService = new CalculadoraImpostoService();
        Double valorProduto = null;

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                () -> calculadoraImpostoService.calcularIcms(valorProduto)
        );

        assertEquals("Valor do produto não pode ser nulo", exception.getMessage());
    }

    @Test
    @DisplayName("Deve lançar IllegalArgumentException quando o valor do produto for zero")
    void deveLancarIllegalArgumentExceptionQuandoOValorDoProdutoForZero() {

        CalculadoraImpostoService calculadoraImpostoService = new CalculadoraImpostoService();
        Double valorProduto = 0.0;

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                () -> calculadoraImpostoService.calcularIcms(valorProduto)
        );

        assertEquals("Valor do produto não pode ser zero", exception.getMessage());
    }

    @Test
    @DisplayName("Deve lançar IllegalArgumentException quando o valor do produto for negativo")
    void deveLancarIllegalArgumentExceptionQuandoOValorDoProdutoForNegativo() {

        CalculadoraImpostoService calculadoraImpostoService = new CalculadoraImpostoService();
        Double valorProduto = -1.0;

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                () -> calculadoraImpostoService.calcularIcms(valorProduto)
        );

        assertEquals("Valor do produto não pode ser negativo", exception.getMessage());
    }
}