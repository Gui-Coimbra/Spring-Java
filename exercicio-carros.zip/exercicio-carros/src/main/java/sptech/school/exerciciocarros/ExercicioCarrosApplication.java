package sptech.school.exerciciocarros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExercicioCarrosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExercicioCarrosApplication.class, args);
	}

}
