package sptech.school.exerciciocarros;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/carros")
public class CarroController {

    @Autowired
    private CarroRepository carroRepository;

    @GetMapping
    public ResponseEntity<List<Carro>> listar(){
        List<Carro> carros = carroRepository.findAll();

        if(carros.isEmpty()){
            return ResponseEntity.status(204).build();
        }
        return ResponseEntity.status(200).body(carros);
    }

    @PostMapping
    public ResponseEntity<Carro> cadastrar(@RequestBody @Valid Carro novoCarro){
        Carro carro = this.carroRepository.save(novoCarro);
        return ResponseEntity.status(201).body(novoCarro);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Carro> buscarPorId(@PathVariable Integer id){
        Optional<Carro> optionalCarro = this.carroRepository.findById(id);

        if(optionalCarro.isPresent()){
            Carro carro = optionalCarro.get();
            return ResponseEntity.status(200).body(carro);
        }
        return ResponseEntity.status(404).build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> remover(@PathVariable Integer id){

        if(this.carroRepository.existsById(id)){
            this.carroRepository.existsById(id);
            return ResponseEntity.status(204).build();
        };
        return ResponseEntity.status(404).build();
    }
}
