package sptech.school.exerciciocarros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExercicioCarrosApplicationTests {

	@Test
	void contextLoads() {
	}

}
