package school.sptech.avaliacaocontinuadadois.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import school.sptech.avaliacaocontinuadadois.domain.Produto;

/*
    Dev:
        Digite seu RA:
        Digite seu nome:

    TODO: Não esqueca de implementar os "dynamics finders" aqui...
*/
public interface ProdutoRepository extends JpaRepository<Produto, Long> {

}
