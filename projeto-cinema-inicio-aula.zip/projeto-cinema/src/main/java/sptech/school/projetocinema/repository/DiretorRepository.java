package sptech.school.projetocinema.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import sptech.school.projetocinema.domain.Diretor;

public interface DiretorRepository extends JpaRepository<Diretor, Long> {

}
