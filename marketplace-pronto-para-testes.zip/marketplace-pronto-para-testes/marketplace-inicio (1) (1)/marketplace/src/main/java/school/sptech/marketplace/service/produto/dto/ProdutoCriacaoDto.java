package school.sptech.marketplace.service.produto.dto;

public class ProdutoCriacaoDto {

    private String nome;
    private String descricao;
    private Double preco;
    private int quantidade;

    public ProdutoCriacaoDto() {
    }

    public ProdutoCriacaoDto(String nome, String descricao, Double preco, int quantidade) {
        this.nome = nome;
        this.descricao = descricao;
        this.preco = preco;
        this.quantidade = quantidade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Double getPreco() {
        return preco;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
}
