package school.sptech.projetoorm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoOrmApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoOrmApplication.class, args);
	}

}
