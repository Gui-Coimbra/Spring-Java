package school.sptech.projetoorm;

import java.time.LocalDate;

public class MusicaRespostaSimples {

  private Integer id;

  private String nome;

  private String album;

  private LocalDate dataLancamento; // ano-mes-dia, exemplo: 1993-06-11

  private Double duracao;

  private Integer ranking;

  public MusicaRespostaSimples(Musica musicaEntidade) {
    this.id = musicaEntidade.getId();
    this.nome = musicaEntidade.getNome();
    this.album = musicaEntidade.getAlbum();
    this.dataLancamento = musicaEntidade.getDataLancamento();
    this.duracao = musicaEntidade.getDuracao();
    this.ranking = musicaEntidade.getRanking();
  }

  public Integer getId() {
    return id;
  }

  public String getNome() {
    return nome;
  }

  public String getAlbum() {
    return album;
  }

  public LocalDate getDataLancamento() {
    return dataLancamento;
  }

  public Double getDuracao() {
    return duracao;
  }

  public Integer getRanking() {
    return ranking;
  }
}
