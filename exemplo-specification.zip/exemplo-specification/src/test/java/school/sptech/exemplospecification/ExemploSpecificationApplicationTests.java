package school.sptech.exemplospecification;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemploSpecificationApplicationTests {

	@Test
	void contextLoads() {
	}

}
