package school.sptech.exemplospecification.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import school.sptech.exemplospecification.domain.Filme;

public interface FilmeRepository extends JpaRepository<Filme, Long> {

}
