package school.sptech.exemplospecification;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExemploSpecificationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExemploSpecificationApplication.class, args);
	}
}
