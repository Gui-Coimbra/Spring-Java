package school.sptech.exemplospecification.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "filme")
public class Filme {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id")
  private Long id;

  @Column(name = "titulo", nullable = false)
  private String titulo;

  @Column(name = "data_lancamento")
  private LocalDate dataLancamento;

  @Column(name = "nota_imdb")
  private Double notaImdb;

  @Column(name = "duracao_minutos")
  private Integer duracaoMinutos;

  @ManyToMany
  @JoinTable(name = "filme_genero",
      joinColumns = @JoinColumn(name = "filme_id"),
      inverseJoinColumns = @JoinColumn(name = "genero_id"))
  private List<Genero> genero;

  @ManyToMany
  @JoinTable(name = "filme_ator",
      joinColumns = @JoinColumn(name = "filme_id"),
      inverseJoinColumns = @JoinColumn(name = "ator_id"))
  private List<Ator> ator;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getTitulo() {
    return titulo;
  }

  public void setTitulo(String titulo) {
    this.titulo = titulo;
  }

  public LocalDate getDataLancamento() {
    return dataLancamento;
  }

  public void setDataLancamento(LocalDate dataLancamento) {
    this.dataLancamento = dataLancamento;
  }

  public Double getNotaImdb() {
    return notaImdb;
  }

  public void setNotaImdb(Double notaImdb) {
    this.notaImdb = notaImdb;
  }

  public Integer getDuracaoMinutos() {
    return duracaoMinutos;
  }

  public void setDuracaoMinutos(Integer duracaoMinutos) {
    this.duracaoMinutos = duracaoMinutos;
  }

  public List<Genero> getGenero() {
    return genero;
  }

  public void setGenero(List<Genero> genero) {
    this.genero = genero;
  }

  public List<Ator> getAtor() {
    return ator;
  }

  public void setAtor(List<Ator> ator) {
    this.ator = ator;
  }
}
