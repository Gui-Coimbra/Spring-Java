CREATE TABLE filme (
   id BIGINT AUTO_INCREMENT NOT NULL,
   titulo VARCHAR(255) NOT NULL,
   data_lancamento date NULL,
   nota_imdb DOUBLE NULL,
   duracao_minutos INT NULL,
   CONSTRAINT pk_filme PRIMARY KEY (id)
);

CREATE TABLE genero (
  id BIGINT AUTO_INCREMENT NOT NULL,
   nome VARCHAR(255) NULL,
   CONSTRAINT pk_genero PRIMARY KEY (id)
);

CREATE TABLE ator (
  id BIGINT AUTO_INCREMENT NOT NULL,
   nome VARCHAR(255) NULL,
   CONSTRAINT pk_ator PRIMARY KEY (id)
);

CREATE TABLE filme_genero (
  filme_id BIGINT NOT NULL,
   genero_id BIGINT NOT NULL
);

ALTER TABLE filme_genero ADD CONSTRAINT fk_filgen_on_filme FOREIGN KEY (filme_id) REFERENCES filme (id);

ALTER TABLE filme_genero ADD CONSTRAINT fk_filgen_on_genero FOREIGN KEY (genero_id) REFERENCES genero (id);

CREATE TABLE filme_ator (
  ator_id BIGINT NOT NULL,
   filme_id BIGINT NOT NULL
);

ALTER TABLE filme_ator ADD CONSTRAINT fk_filato_on_ator FOREIGN KEY (ator_id) REFERENCES ator (id);

ALTER TABLE filme_ator ADD CONSTRAINT fk_filato_on_filme FOREIGN KEY (filme_id) REFERENCES filme (id);

INSERT INTO filme (id, titulo, data_lancamento, nota_imdb, duracao_minutos) VALUES (1, 'O Poderoso Chefão', '1972-03-24', 9.2, 175);
INSERT INTO filme (id, titulo, data_lancamento, nota_imdb, duracao_minutos) VALUES (2, 'O Poderoso Chefão II', '1974-12-20', 9.0, 202);
INSERT INTO filme (id, titulo, data_lancamento, nota_imdb, duracao_minutos) VALUES (3, 'Batman: O Cavaleiro das Trevas', '2008-07-18', 9.0, 152);
INSERT INTO filme (id, titulo, data_lancamento, nota_imdb, duracao_minutos) VALUES (4, 'Pulp Fiction: Tempo de Violência', '1994-10-28', 8.9, 154);
INSERT INTO filme (id, titulo, data_lancamento, nota_imdb, duracao_minutos) VALUES (5, 'O Senhor dos Anéis: O Retorno do Rei', '2003-12-25', 8.9, 201);
INSERT INTO filme (id, titulo, data_lancamento, nota_imdb, duracao_minutos) VALUES (6, 'O Bom, o Mau e o Vilão', '1966-12-23', 8.8, 161);
INSERT INTO filme (id, titulo, data_lancamento, nota_imdb, duracao_minutos) VALUES (7, '12 Homens e uma Sentença', '1957-04-10', 8.9, 96);
INSERT INTO filme (id, titulo, data_lancamento, nota_imdb, duracao_minutos) VALUES (8, 'A Lista de Schindler', '1994-02-04', 8.9, 195);
INSERT INTO filme (id, titulo, data_lancamento, nota_imdb, duracao_minutos) VALUES (9, 'O Senhor dos Anéis: A Sociedade do Anel', '2001-12-19', 8.8, 178);
INSERT INTO filme (id, titulo, data_lancamento, nota_imdb, duracao_minutos) VALUES (10, 'Forrest Gump: O Contador de Histórias', '1994-07-06', 8.8, 142);
INSERT INTO filme (id, titulo, data_lancamento, nota_imdb, duracao_minutos) VALUES (11, 'Guerra nas Estrelas', '1977-05-25', 8.6, 121);
INSERT INTO filme (id, titulo, data_lancamento, nota_imdb, duracao_minutos) VALUES (12, 'O Senhor dos Anéis: As Duas Torres', '2002-12-18', 8.7, 179);
INSERT INTO filme (id, titulo, data_lancamento, nota_imdb, duracao_minutos) VALUES (13, 'Matrix', '1999-06-11', 8.7, 136);
INSERT INTO filme (id, titulo, data_lancamento, nota_imdb, duracao_minutos) VALUES (14, 'Os Bons Companheiros', '1990-09-21', 8.7, 146);
INSERT INTO filme (id, titulo, data_lancamento, nota_imdb, duracao_minutos) VALUES (15, 'Interestelar', '2014-11-07', 8.6, 169);
INSERT INTO filme (id, titulo, data_lancamento, nota_imdb, duracao_minutos) VALUES (16, 'Cidade de Deus', '2002-02-08', 8.6, 130);
INSERT INTO filme (id, titulo, data_lancamento, nota_imdb, duracao_minutos) VALUES (17, 'O Silêncio dos Inocentes', '1991-02-14', 8.6, 118);
INSERT INTO filme (id, titulo, data_lancamento, nota_imdb, duracao_minutos) VALUES (18, 'Os Sete Samurais', '1954-04-26', 8.6, 207);
INSERT INTO filme (id, titulo, data_lancamento, nota_imdb, duracao_minutos) VALUES (19, 'Vingadores: Guerra Infinita', '2018-04-27', 8.5, 149);
INSERT INTO filme (id, titulo, data_lancamento, nota_imdb, duracao_minutos) VALUES (20, 'A Vida é Bela', '1997-12-20', 8.6, 116);
INSERT INTO filme (id, titulo, data_lancamento, nota_imdb, duracao_minutos) VALUES (21, 'Seven: Os Sete Crimes Capitais', '1995-11-17', 8.6, 127);
INSERT INTO filme (id, titulo, data_lancamento, nota_imdb, duracao_minutos) VALUES (22, 'A Felicidade Não se Compra', '1946-01-07', 8.6, 130);
INSERT INTO filme (id, titulo, data_lancamento, nota_imdb, duracao_minutos) VALUES (23, 'A Viagem de Chihiro', '2001-07-27', 8.6, 125);

INSERT INTO genero (id, nome) VALUES (1, 'Crime');
INSERT INTO genero (id, nome) VALUES (2, 'Drama');
INSERT INTO genero (id, nome) VALUES (3, 'Ação');
INSERT INTO genero (id, nome) VALUES (4, 'Aventura');
INSERT INTO genero (id, nome) VALUES (5, 'Ficção científica');
INSERT INTO genero (id, nome) VALUES (6, 'Fantasia');
INSERT INTO genero (id, nome) VALUES (7, 'Guerra');
INSERT INTO genero (id, nome) VALUES (8, 'Comédia');
INSERT INTO genero (id, nome) VALUES (9, 'Animação');
INSERT INTO genero (id, nome) VALUES (10, 'Mistério');
INSERT INTO genero (id, nome) VALUES (11, 'Faroeste');
INSERT INTO genero (id, nome) VALUES (12, 'Thriller');
INSERT INTO genero (id, nome) VALUES (13, 'Histórico');
INSERT INTO genero (id, nome) VALUES (14, 'Biografia');
INSERT INTO genero (id, nome) VALUES (15, 'Romance');
INSERT INTO genero (id, nome) VALUES (16, 'Musical');
INSERT INTO genero (id, nome) VALUES (17, 'Esporte');
INSERT INTO genero (id, nome) VALUES (18, 'Documentário');
INSERT INTO genero (id, nome) VALUES (19, 'Família');
INSERT INTO genero (id, nome) VALUES (20, 'Curta-metragem');
INSERT INTO genero (id, nome) VALUES (21, 'Reality-TV');
INSERT INTO genero (id, nome) VALUES (22, 'Game-Show');
INSERT INTO genero (id, nome) VALUES (23, 'Terror');
INSERT INTO genero (id, nome) VALUES (24, 'Música');
INSERT INTO genero (id, nome) VALUES (25, 'Western');

INSERT INTO ator (id, nome) VALUES (1, 'Tim Robbins');
INSERT INTO ator (id, nome) VALUES (2, 'Morgan Freeman');
INSERT INTO ator (id, nome) VALUES (3, 'Bob Gunton');
INSERT INTO ator (id, nome) VALUES (4, 'William Sadler');
INSERT INTO ator (id, nome) VALUES (5, 'Clancy Brown');
INSERT INTO ator (id, nome) VALUES (6, 'Gil Bellows');
INSERT INTO ator (id, nome) VALUES (7, 'Mark Rolston');
INSERT INTO ator (id, nome) VALUES (8, 'James Whitmore');
INSERT INTO ator (id, nome) VALUES (9, 'Jeffrey DeMunn');
INSERT INTO ator (id, nome) VALUES (10, 'Larry Brandenburg');
INSERT INTO ator (id, nome) VALUES (11, 'Neil Giuntoli');
INSERT INTO ator (id, nome) VALUES (12, 'Brian Libby');
INSERT INTO ator (id, nome) VALUES (13, 'David Proval');
INSERT INTO ator (id, nome) VALUES (14, 'Joseph Ragno');
INSERT INTO ator (id, nome) VALUES (15, 'Jude Ciccolella');
INSERT INTO ator (id, nome) VALUES (16, 'Paul McCrane');
INSERT INTO ator (id, nome) VALUES (17, 'Renee Blaine');
INSERT INTO ator (id, nome) VALUES (18, 'Scott Mann');
INSERT INTO ator (id, nome) VALUES (19, 'John Horton');
INSERT INTO ator (id, nome) VALUES (20, 'Gordon Greene');
INSERT INTO ator (id, nome) VALUES (21, 'Marlon Brando');
INSERT INTO ator (id, nome) VALUES (22, 'Al Pacino');
INSERT INTO ator (id, nome) VALUES (23, 'James Caan');
INSERT INTO ator (id, nome) VALUES (24, 'Richard S. Castellano');
INSERT INTO ator (id, nome) VALUES (25, 'Robert Duvall');
INSERT INTO ator (id, nome) VALUES (26, 'Sterling Hayden');
INSERT INTO ator (id, nome) VALUES (27, 'John Marley');
INSERT INTO ator (id, nome) VALUES (28, 'Richard Conte');
INSERT INTO ator (id, nome) VALUES (29, 'Al Lettieri');
INSERT INTO ator (id, nome) VALUES (30, 'Diane Keaton');
INSERT INTO ator (id, nome) VALUES (31, 'Abe Vigoda');
INSERT INTO ator (id, nome) VALUES (32, 'Christian Bale');
INSERT INTO ator (id, nome) VALUES (33, 'Heath Ledger');
INSERT INTO ator (id, nome) VALUES (34, 'Aaron Eckhart');
INSERT INTO ator (id, nome) VALUES (35, 'Michael Caine');
INSERT INTO ator (id, nome) VALUES (36, 'Maggie Gyllenhaal');
INSERT INTO ator (id, nome) VALUES (37, 'Gary Oldman');
INSERT INTO ator (id, nome) VALUES (38, 'John Travolta');
INSERT INTO ator (id, nome) VALUES (39, 'Uma Thurman');
INSERT INTO ator (id, nome) VALUES (40, 'Samuel L. Jackson');
INSERT INTO ator (id, nome) VALUES (41, 'Bruce Willis');
INSERT INTO ator (id, nome) VALUES (42, 'Ving Rhames');
INSERT INTO ator (id, nome) VALUES (43, 'Elijah Wood');
INSERT INTO ator (id, nome) VALUES (44, 'Ian McKellen');
INSERT INTO ator (id, nome) VALUES (45, 'Orlando Bloom');
INSERT INTO ator (id, nome) VALUES (46, 'Sean Bean');
INSERT INTO ator (id, nome) VALUES (47, 'Sean Astin');
INSERT INTO ator (id, nome) VALUES (48, 'Liam Neeson');
INSERT INTO ator (id, nome) VALUES (49, 'Ralph Fiennes');
INSERT INTO ator (id, nome) VALUES (50, 'Ben Kingsley');
INSERT INTO ator (id, nome) VALUES (51, 'Caroline Goodall');
INSERT INTO ator (id, nome) VALUES (52, 'Jonathan Sagall');
INSERT INTO ator (id, nome) VALUES (53, 'Brad Pitt');
INSERT INTO ator (id, nome) VALUES (54, 'Edward Norton');
INSERT INTO ator (id, nome) VALUES (55, 'Helena Bonham Carter');
INSERT INTO ator (id, nome) VALUES (56, 'Meat Loaf');
INSERT INTO ator (id, nome) VALUES (57, 'Jared Leto');
INSERT INTO ator (id, nome) VALUES (58, 'Ewan McGregor');
INSERT INTO ator (id, nome) VALUES (59, 'Liam Neeson');
INSERT INTO ator (id, nome) VALUES (60, 'Natalie Portman');
INSERT INTO ator (id, nome) VALUES (61, 'Jake Lloyd');
INSERT INTO ator (id, nome) VALUES (62, 'Ian McDiarmid');
INSERT INTO ator (id, nome) VALUES (63, 'Mark Hamill');
INSERT INTO ator (id, nome) VALUES (64, 'Harrison Ford');
INSERT INTO ator (id, nome) VALUES (65, 'Carrie Fisher');
INSERT INTO ator (id, nome) VALUES (66, 'Alexandre Rodrigues');
INSERT INTO ator (id, nome) VALUES (67, 'Alec Guinness');
INSERT INTO ator (id, nome) VALUES (68, 'Leonardo DiCaprio');
INSERT INTO ator (id, nome) VALUES (69, 'Joseph Gordon-Levitt');
INSERT INTO ator (id, nome) VALUES (70, 'Ellen Page');
INSERT INTO ator (id, nome) VALUES (71, 'Tom Hardy');
INSERT INTO ator (id, nome) VALUES (72, 'Ken Watanabe');
INSERT INTO ator (id, nome) VALUES (73, 'Tom Hanks');
INSERT INTO ator (id, nome) VALUES (74, 'Robin Wright');
INSERT INTO ator (id, nome) VALUES (75, 'Gary Sinise');
INSERT INTO ator (id, nome) VALUES (76, 'Mykelti Williamson');
INSERT INTO ator (id, nome) VALUES (77, 'Sally Field');
INSERT INTO ator (id, nome) VALUES (78, 'Henry Thomas');
INSERT INTO ator (id, nome) VALUES (79, 'Drew Barrymore');
INSERT INTO ator (id, nome) VALUES (80, 'Peter Coyote');
INSERT INTO ator (id, nome) VALUES (81, 'Dee Wallace');
INSERT INTO ator (id, nome) VALUES (82, 'Robert MacNaughton');
INSERT INTO ator (id, nome) VALUES (83, 'Harrison Ford');
INSERT INTO ator (id, nome) VALUES (84, 'Karen Allen');
INSERT INTO ator (id, nome) VALUES (85, 'Paul Freeman');
INSERT INTO ator (id, nome) VALUES (86, 'Ronald Lacey');
INSERT INTO ator (id, nome) VALUES (87, 'John Rhys-Davies');
INSERT INTO ator (id, nome) VALUES (88, 'Roberto Benigni');
INSERT INTO ator (id, nome) VALUES (89, 'Daveigh Chase');

-- Relacionar filmes aos gêneros
INSERT INTO filme_genero (filme_id, genero_id) VALUES
  (1, 1), -- O Poderoso Chefão - Crime
  (1, 2), -- O Poderoso Chefão - Drama
  (2, 1), -- O Poderoso Chefão II - Crime
  (2, 2), -- O Poderoso Chefão II - Drama
  (3, 3), -- Batman: O Cavaleiro das Trevas - Ação
  (3, 12), -- Batman: O Cavaleiro das Trevas - Thriller
  (4, 1), -- Pulp Fiction: Tempo de Violência - Crime
  (4, 12), -- Pulp Fiction: Tempo de Violência - Thriller
  (5, 4), -- O Senhor dos Anéis: O Retorno do Rei - Aventura
  (5, 6), -- O Senhor dos Anéis: O Retorno do Rei - Fantasia
  (6, 1), -- O Bom, o Mau e o Vilão - Crime
  (6, 11), -- O Bom, o Mau e o Vilão - Faroeste
  (7, 12), -- 12 Homens e uma Sentença - Thriller
  (8, 7), -- A Lista de Schindler - Guerra
  (8, 13), -- A Lista de Schindler - Histórico
  (9, 4), -- O Senhor dos Anéis: A Sociedade do Anel - Aventura
  (9, 6), -- O Senhor dos Anéis: A Sociedade do Anel - Fantasia
  (10, 2), -- Forrest Gump: O Contador de Histórias - Drama
  (10, 8), -- Forrest Gump: O Contador de Histórias - Comédia
  (11, 3), -- Guerra nas Estrelas - Ação
  (11, 5), -- Guerra nas Estrelas - Ficção científica
  (12, 4), -- O Senhor dos Anéis: As Duas Torres - Aventura
  (12, 6), -- O Senhor dos Anéis: As Duas Torres - Fantasia
  (13, 5), -- Matrix - Ficção científica
  (13, 12), -- Matrix - Thriller
  (14, 1), -- Os Bons Companheiros - Crime
  (14, 12), -- Os Bons Companheiros - Thriller
  (15, 5), -- Interestelar - Ficção científica
  (15, 12), -- Interestelar - Thriller
  (16, 1), -- Cidade de Deus - Crime
  (16, 2), -- Cidade de Deus - Drama
  (17, 1), -- O Silêncio dos Inocentes - Crime
  (17, 12), -- O Silêncio dos Inocentes - Thriller
  (18, 2), -- Os Sete Samurais - Drama
  (18, 7), -- Os Sete Samurais - Guerra
  (19, 2), -- Vingadores: Guerra Infinita - Drama
  (19, 4), -- Vingadores: Guerra Infinita - Aventura
  (20, 2), -- A Vida é Bela - Drama
  (20, 8), -- A Vida é Bela - Comédia
  (21, 1), -- Seven: Os Sete Crimes Capitais - Crime
  (21, 12), -- Seven: Os Sete Crimes Capitais - Thriller
  (22, 8), -- A Felicidade Não se Compra - Comédia
  (22, 2), -- A Felicidade Não se Compra - Drama
  (23, 9), -- A Viagem de Chihiro - Animação
  (23, 6); -- A Viagem de Chihiro - Fantasia

-- Relacionamentos para o filme 'O Poderoso Chefão'
INSERT INTO filme_ator (filme_id, ator_id) VALUES (1, 21); -- Marlon Brando
INSERT INTO filme_ator (filme_id, ator_id) VALUES (1, 22); -- Al Pacino
INSERT INTO filme_ator (filme_id, ator_id) VALUES (1, 23); -- James Caan
INSERT INTO filme_ator (filme_id, ator_id) VALUES (1, 24); -- Richard S. Castellano
INSERT INTO filme_ator (filme_id, ator_id) VALUES (1, 25); -- Robert Duvall

-- Relacionamentos para o filme 'O Poderoso Chefão II'
INSERT INTO filme_ator (filme_id, ator_id) VALUES (2, 22); -- Al Pacino
INSERT INTO filme_ator (filme_id, ator_id) VALUES (2, 23); -- James Caan
INSERT INTO filme_ator (filme_id, ator_id) VALUES (2, 25); -- Robert Duvall

-- Relacionamentos para o filme 'Batman: O Cavaleiro das Trevas'
INSERT INTO filme_ator (filme_id, ator_id) VALUES (3, 32); -- Christian Bale
INSERT INTO filme_ator (filme_id, ator_id) VALUES (3, 33); -- Heath Ledger
INSERT INTO filme_ator (filme_id, ator_id) VALUES (3, 34); -- Aaron Eckhart
INSERT INTO filme_ator (filme_id, ator_id) VALUES (3, 35); -- Michael Caine
INSERT INTO filme_ator (filme_id, ator_id) VALUES (3, 36); -- Maggie Gyllenhaal
INSERT INTO filme_ator (filme_id, ator_id) VALUES (3, 37); -- Gary Oldman

INSERT INTO filme_ator (filme_id, ator_id) VALUES (4, 38); -- Pulp Fiction: Tempo de Violência - John Travolta
INSERT INTO filme_ator (filme_id, ator_id) VALUES (4, 39); -- Pulp Fiction: Tempo de Violência - Uma Thurman
INSERT INTO filme_ator (filme_id, ator_id) VALUES (4, 40); -- Pulp Fiction: Tempo de Violência - Samuel L. Jackson

INSERT INTO filme_ator (filme_id, ator_id) VALUES (5, 43); -- O Senhor dos Anéis: O Retorno do Rei - Elijah Wood
INSERT INTO filme_ator (filme_id, ator_id) VALUES (5, 44); -- O Senhor dos Anéis: O Retorno do Rei - Ian McKellen
INSERT INTO filme_ator (filme_id, ator_id) VALUES (5, 45); -- O Senhor dos Anéis: O Retorno do Rei - Orlando Bloom

-- Relacionando atores ao filme "O Bom, o Mau e o Vilão"
INSERT INTO filme_ator (filme_id, ator_id) VALUES (6, 46); -- Sean Bean
INSERT INTO filme_ator (filme_id, ator_id) VALUES (6, 21); -- Marlon Brando

-- Relacionando atores ao filme "12 Homens e uma Sentença"
INSERT INTO filme_ator (filme_id, ator_id) VALUES (7, 1); -- Tim Robbins
INSERT INTO filme_ator (filme_id, ator_id) VALUES (7, 2); -- Morgan Freeman
INSERT INTO filme_ator (filme_id, ator_id) VALUES (7, 3); -- Bob Gunton
INSERT INTO filme_ator (filme_id, ator_id) VALUES (7, 4); -- William Sadler
INSERT INTO filme_ator (filme_id, ator_id) VALUES (7, 5); -- Clancy Brown
INSERT INTO filme_ator (filme_id, ator_id) VALUES (7, 6); -- Gil Bellows
INSERT INTO filme_ator (filme_id, ator_id) VALUES (7, 7); -- Mark Rolston
INSERT INTO filme_ator (filme_id, ator_id) VALUES (7, 8); -- James Whitmore
INSERT INTO filme_ator (filme_id, ator_id) VALUES (7, 9); -- Jeffrey DeMunn
INSERT INTO filme_ator (filme_id, ator_id) VALUES (7, 10); -- Larry Brandenburg
INSERT INTO filme_ator (filme_id, ator_id) VALUES (7, 11); -- Neil Giuntoli
INSERT INTO filme_ator (filme_id, ator_id) VALUES (7, 12); -- Brian Libby

-- Relacionando atores ao filme "A Lista de Schindler"
INSERT INTO filme_ator (filme_id, ator_id) VALUES (8, 1); -- Tim Robbins
INSERT INTO filme_ator (filme_id, ator_id) VALUES (8, 13); -- David Proval
INSERT INTO filme_ator (filme_id, ator_id) VALUES (8, 14); -- Joseph Ragno
INSERT INTO filme_ator (filme_id, ator_id) VALUES (8, 15); -- Jude Ciccolella
INSERT INTO filme_ator (filme_id, ator_id) VALUES (8, 16); -- Paul McCrane
INSERT INTO filme_ator (filme_id, ator_id) VALUES (8, 17); -- Renee Blaine
INSERT INTO filme_ator (filme_id, ator_id) VALUES (8, 18); -- Scott Mann
INSERT INTO filme_ator (filme_id, ator_id) VALUES (8, 19); -- John Horton
INSERT INTO filme_ator (filme_id, ator_id) VALUES (8, 20); -- Gordon Greene

-- O Senhor dos Anéis: A Sociedade do Anel
INSERT INTO filme_ator (filme_id, ator_id) VALUES (9, 43); -- Elijah Wood

-- Forrest Gump: O Contador de Histórias
INSERT INTO filme_ator (filme_id, ator_id) VALUES (10, 73); -- Tom Hanks

-- Guerra nas Estrelas
INSERT INTO filme_ator (filme_id, ator_id) VALUES (11, 61); -- Mark Hamill
INSERT INTO filme_ator (filme_id, ator_id) VALUES (11, 83); -- Harrison Ford

-- O Senhor dos Anéis: As Duas Torres
INSERT INTO filme_ator (filme_id, ator_id) VALUES (12, 43); -- Elijah Wood

-- Matrix
INSERT INTO filme_ator (filme_id, ator_id) VALUES (13, 32); -- Keanu Reeves

-- Os Bons Companheiros
INSERT INTO filme_ator (filme_id, ator_id) VALUES (14, 38); -- Robert De Niro
INSERT INTO filme_ator (filme_id, ator_id) VALUES (14, 13); -- Joe Pesci

-- Interestelar
INSERT INTO filme_ator (filme_id, ator_id) VALUES (15, 68); -- Matthew McConaughey
INSERT INTO filme_ator (filme_id, ator_id) VALUES (15, 70); -- Anne Hathaway

-- Cidade de Deus
INSERT INTO filme_ator (filme_id, ator_id) VALUES (16, 66); -- Alexandre Rodrigues

-- O Silêncio dos Inocentes
INSERT INTO filme_ator (filme_id, ator_id) VALUES (17, 78); -- Jodie Foster
INSERT INTO filme_ator (filme_id, ator_id) VALUES (17, 79); -- Anthony Hopkins

-- Os Sete Samurais
INSERT INTO filme_ator (filme_id, ator_id) VALUES (18, 20); -- Toshiro Mifune

-- Vingadores: Guerra Infinita
INSERT INTO filme_ator (filme_id, ator_id) VALUES (19, 34); -- Robert Downey Jr.
INSERT INTO filme_ator (filme_id, ator_id) VALUES (19, 40); -- Chris Hemsworth

-- A Vida é Bela
INSERT INTO filme_ator (filme_id, ator_id) VALUES (20, 88); -- Roberto Benigni

-- Seven: Os Sete Crimes Capitais
INSERT INTO filme_ator (filme_id, ator_id) VALUES (21, 53); -- Brad Pitt
INSERT INTO filme_ator (filme_id, ator_id) VALUES (21, 54); -- Edward Norton

-- A Felicidade Não se Compra
INSERT INTO filme_ator (filme_id, ator_id) VALUES (22, 81); -- James Stewart

-- A Viagem de Chihiro
INSERT INTO filme_ator (filme_id, ator_id) VALUES (23, 89); -- Daveigh Chase