INSERT INTO escritor (nome) VALUES
 ('J.R.R. Tolkien'),
 ('C.S. Lewis'),
 ('J.K. Rowling'),
 ('Gabriel García Márquez'),
 ('George Orwell'),
 ('F. Scott Fitzgerald'),
 ('Herman Melville'),
 ('Miguel de Cervantes'),
 ('William Shakespeare'),
 ('Franz Kafka');


INSERT INTO livro (nome, genero, lancamento, escritor_id, indicacao_times)VALUES
('O Senhor dos Anéis', 'Fantasia', '2001-12-19', 1, true),
('As Crônicas de Nárnia', 'Fantasia', '2005-12-08', 2, true),
('Harry Potter e a Pedra Filosofal', 'Fantasia', '2001-11-16', 3, true),
('Cem Anos de Solidão', 'Realismo Mágico', '1967-05-30', 4, false),
('1984', 'Distopia', '1949-06-08', 5, false),
('A Revolução dos Bichos', 'Fábula', '1945-08-17', 5, true),
('O Grande Gatsby', 'Romance', '1925-04-10', 6, false),
('Moby Dick', 'Aventura', '1851-10-18', 7, true),
('Dom Quixote', 'Romance', '1605-01-16', 8, true),
('Romeu e Julieta', 'Tragédia', '1597-01-20', 9, false),
('Macbeth', 'Tragédia', '1623-01-01', 9, true),
('A Metamorfose', 'Ficção Absurda', '1915-10-15', 10, true),
('O Processo', 'Ficção Absurda', '1925-01-01', 10, false);

