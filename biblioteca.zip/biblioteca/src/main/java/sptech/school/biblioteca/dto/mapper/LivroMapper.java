package sptech.school.biblioteca.dto.mapper;

import sptech.school.biblioteca.domain.Escritor;
import sptech.school.biblioteca.domain.Livro;
import sptech.school.biblioteca.dto.Resumo.EscritorResumoDto;
import sptech.school.biblioteca.dto.Resumo.LivroResumoDto;
import sptech.school.biblioteca.dto.detalhe.LivroDetalheDto;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

public class LivroMapper {
    private LivroMapper() {
        throw new IllegalStateException("Classe utilitária");
    }

    public static LivroDetalheDto paraDetalheDto(Livro dominio) {

        if (Objects.isNull(dominio)) {
            return null;
        }

        LivroDetalheDto livroDetalhe = new LivroDetalheDto();

        livroDetalhe.setId(dominio.getId());
        livroDetalhe.setNome(dominio.getNome());
        livroDetalhe.setGenero(dominio.getGenero());
        livroDetalhe.setLancamento(dominio.getLancamento());
        livroDetalhe.setIndicacaoTimes(dominio.isIndicacaoTimes());

        EscritorResumoDto escritor = new EscritorResumoDto();
        escritor.setId(dominio.getEscritor().getId());
        escritor.setNome(dominio.getEscritor().getNome());

        livroDetalhe.setEscritor(escritor);

        return livroDetalhe;
    }

    public static LivroResumoDto paraResumoDto(Livro dominio) {

        if (Objects.isNull(dominio)) {
            return null;
        }

        LivroResumoDto escritor = new LivroResumoDto();

        escritor.setId(dominio.getId());
        escritor.setNome(dominio.getNome());
        escritor.setGenero(dominio.getGenero());
        escritor.setLancamento(dominio.getLancamento());
        escritor.setIndicacaoTimes(dominio.isIndicacaoTimes());

        return escritor;
    }
}
