package sptech.school.biblioteca.dto.detalhe;

import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import sptech.school.biblioteca.domain.Escritor;
import sptech.school.biblioteca.dto.Resumo.EscritorResumoDto;

import java.time.LocalDate;

public class LivroDetalheDto {
    private Long id;
    private String nome;
    private String genero;
    private LocalDate lancamento;
    private boolean indicacaoTimes;
    private EscritorResumoDto escritor;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public LocalDate getLancamento() {
        return lancamento;
    }

    public void setLancamento(LocalDate lancamento) {
        this.lancamento = lancamento;
    }

    public boolean isIndicacaoTimes() {
        return indicacaoTimes;
    }

    public void setIndicacaoTimes(boolean indicacaoTimes) {
        this.indicacaoTimes = indicacaoTimes;
    }

    public EscritorResumoDto getEscritor() {
        return escritor;
    }

    public void setEscritor(EscritorResumoDto escritor) {
        this.escritor = escritor;
    }
}
