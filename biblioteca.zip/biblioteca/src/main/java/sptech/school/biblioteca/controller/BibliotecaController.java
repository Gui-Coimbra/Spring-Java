package sptech.school.biblioteca.controller;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sptech.school.biblioteca.domain.Escritor;
import sptech.school.biblioteca.domain.Livro;
import sptech.school.biblioteca.dto.Resumo.LivroResumoDto;
import sptech.school.biblioteca.dto.detalhe.EscritorDetalheDto;
import sptech.school.biblioteca.dto.detalhe.LivroDetalheDto;
import sptech.school.biblioteca.dto.mapper.EscritorMapper;
import sptech.school.biblioteca.dto.mapper.LivroMapper;
import sptech.school.biblioteca.repository.EscritorRepository;
import sptech.school.biblioteca.repository.LivroRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/biblioteca")
public class BibliotecaController {

    @Autowired
    private LivroRepository livroRepository;

    @Autowired
    private EscritorRepository escritorRepository;

    @GetMapping("/escritores")
    public ResponseEntity<List<EscritorDetalheDto>> listar(){
        List<Escritor> escritores = this.escritorRepository.findAll();

        if (escritores.isEmpty()){
            return ResponseEntity.status(204).build();
        }

        List<EscritorDetalheDto> escritoresDto = escritores.stream()
                .map(EscritorMapper::paraDetalhesDto)
                .toList();

        return ResponseEntity.status(200).body(escritoresDto);
    }

    @GetMapping("/livros")
    public ResponseEntity<List<LivroDetalheDto>> listarLivros(){
        List<Livro> livros = this.livroRepository.findAll();

        if (livros.isEmpty()){
            return ResponseEntity.status(204).build();
        }

        List<LivroDetalheDto> livrosDto = livros.stream()
                .map(LivroMapper::paraDetalheDto)
                .toList();

        return ResponseEntity.status(200).body(livrosDto);
    }

    @PostMapping("/escritores")
    public ResponseEntity<EscritorDetalheDto> cadastrarEscritor(@RequestBody @Valid Escritor escritor){
        Escritor escritorRegristrado = escritorRepository.save(escritor);
        return ResponseEntity.status(201).body(EscritorMapper.paraDetalhesDto(escritorRegristrado));
    }

    @PostMapping("/livros")
    public ResponseEntity<LivroDetalheDto> cadastrarLivro(@RequestBody @Valid Livro livro){
        Livro livroRegristrado = livroRepository.save(livro);
        return ResponseEntity.status(201).body(LivroMapper.paraDetalheDto(livroRegristrado));
    }

    @GetMapping("/livros/nome")
    public ResponseEntity<LivroDetalheDto> buscaPorNome(@RequestParam String nome){
        Optional<Livro> livro = livroRepository.findByNomeContainsIgnoreCase(nome);
        if(livro.isPresent()){
            return ResponseEntity.status(200).body(LivroMapper.paraDetalheDto(livro.get()));
        }
        return ResponseEntity.status(404).build();
    }

    @GetMapping("/indicados/escritor")
    public ResponseEntity<Integer> indicadosPorEscritor(@RequestParam String escritor) {
        int contagem = this.livroRepository.contagemLivrosIndicadosPorEscritor(escritor);
        return ResponseEntity.status(200).body(contagem);
    }

    @Transactional
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletarPorId(@PathVariable Long id) {
        if (this.livroRepository.existsById(id)) {
            this.livroRepository.deletaPorId(id);
            return ResponseEntity.status(204).build();
        }

        return ResponseEntity.status(404).build();
    }

    @Transactional
    @PatchMapping("/{id}")
    public ResponseEntity<Void> atualizaNovoNome(@PathVariable Long id, @RequestParam String nome) {
        if (this.livroRepository.existsById(id)) {
            this.livroRepository.atualizaNomePorId(id, nome);
            return ResponseEntity.status(200).build();
        }

        return ResponseEntity.status(404).build();
    }

    @GetMapping("/livros/ordem-lancamento")
    public ResponseEntity<List<LivroDetalheDto>> ordemLancamento(){
        List<Livro> livros = livroRepository.findByOrderByLancamentoDesc();
        if(livros.isEmpty()){
           return ResponseEntity.status(404).build();
        }
        List<LivroDetalheDto> livrosDto = livros.stream()
                .map(LivroMapper::paraDetalheDto)
                .toList();
        return ResponseEntity.status(200).body(livrosDto);
    }

    @GetMapping("/livros/data")
    public ResponseEntity<List<LivroDetalheDto>> dataLancamento(@RequestParam LocalDate data1,
                                                                @RequestParam LocalDate data2){
        List<Livro> livros = livroRepository.findByLancamentoBetween(data1, data2);
        if(livros.isEmpty()){
            return ResponseEntity.status(404).build();
        }
        List<LivroDetalheDto> livrosDto = livros.stream()
                .map(LivroMapper::paraDetalheDto)
                .toList();
        return ResponseEntity.status(200).body(livrosDto);
    }
}
