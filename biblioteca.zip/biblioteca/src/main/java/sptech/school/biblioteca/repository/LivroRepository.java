package sptech.school.biblioteca.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import sptech.school.biblioteca.domain.Livro;
import sptech.school.biblioteca.dto.Resumo.LivroResumoDto;
import sptech.school.biblioteca.dto.detalhe.LivroDetalheDto;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface LivroRepository extends JpaRepository<Livro, Long> {

//    @Query("SELECT new sptech.school.biblioteca.dto.Resumo.LivroResumoDto(l.nome) FROM Livro l")
//    List<LivroResumoDto> listagemResumo();

    Optional<Livro> findByNomeContainsIgnoreCase(String nome);

    List<Livro> findByOrderByLancamentoDesc();

    List<Livro> findByLancamentoBetween(LocalDate data1, LocalDate data2);

    @Query("SELECT COUNT(l) FROM Livro l WHERE l.indicacaoTimes AND l.escritor.nome iLike %:escritor%")
    int contagemLivrosIndicadosPorEscritor(String escritor);

    @Modifying
    @Query("DELETE FROM Livro l WHERE l.id = :id")
    void deletaPorId(Long id);

    @Modifying
    @Query("UPDATE Livro l SET l.nome = :nome WHERE l.id = :id")
    void atualizaNomePorId(Long id, String nome);

}
