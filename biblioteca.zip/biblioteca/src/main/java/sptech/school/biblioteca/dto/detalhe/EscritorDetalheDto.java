package sptech.school.biblioteca.dto.detalhe;

import sptech.school.biblioteca.dto.Resumo.LivroResumoDto;

import java.util.List;

public class EscritorDetalheDto {

    private long id;
    private String nome;
    private List<LivroResumoDto> livros;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public List<LivroResumoDto> getLivros() {
        return livros;
    }

    public void setLivros(List<LivroResumoDto> livros) {
        this.livros = livros;
    }
}
