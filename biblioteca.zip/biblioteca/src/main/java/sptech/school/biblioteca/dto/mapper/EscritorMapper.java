package sptech.school.biblioteca.dto.mapper;

import sptech.school.biblioteca.domain.Escritor;
import sptech.school.biblioteca.dto.Resumo.EscritorResumoDto;
import sptech.school.biblioteca.dto.Resumo.LivroResumoDto;
import sptech.school.biblioteca.dto.detalhe.EscritorDetalheDto;
import sptech.school.biblioteca.dto.detalhe.LivroDetalheDto;

import java.util.List;
import java.util.Objects;

public class EscritorMapper {

    private EscritorMapper() {
        throw new IllegalStateException("Classe utilitária");
    }

    public static EscritorDetalheDto paraDetalhesDto(Escritor dominio) {

        if (Objects.isNull(dominio)) {
            return null;
        }

        EscritorDetalheDto escritor = new EscritorDetalheDto();

        escritor.setId(dominio.getId());
        escritor.setNome(dominio.getNome());

        List<LivroResumoDto> livrosDto = dominio.getLivros().stream()
                .map(LivroMapper::paraResumoDto)
                .toList();

        escritor.setLivros(livrosDto);

        return escritor;
    }

    public static EscritorResumoDto paraResumo(Escritor dominio) {

        if (Objects.isNull(dominio)) {
            return null;
        }

        EscritorResumoDto escritor = new EscritorResumoDto();

        escritor.setId(dominio.getId());
        escritor.setNome(dominio.getNome());

        return escritor;
    }
}
