package sptech.school.guilherme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GuilhermeApplication {

	public static void main(String[] args) {
		SpringApplication.run(GuilhermeApplication.class, args);
	}

}
