package sptech.school.guilherme.boletim;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("alunos")
public class AlunoController {

    private List<Aluno> alunos = new ArrayList<>();

    @GetMapping()
    public List<Aluno> listar(){
        return alunos;
    }

    @GetMapping("/{indice}")
    public Aluno retornaIndice(@PathVariable int indice){
        if(indice < alunos.size()){
            return alunos.get(indice);
        }else{
            return null;
        }
    }

    @DeleteMapping("/{indice}")
    public String deletar(@PathVariable int indice){
        if(indice < alunos.size()){
            alunos.remove(indice);
            return "Excluído!";
        }else{
            return "Deu ruim!";
        }
    }

    @PostMapping()
    public Aluno cadastrar(@RequestBody Aluno aluno){
        alunos.add(aluno);
        return aluno;
    }

    @GetMapping("/contagem")
    public int contar(){
        return alunos.size();
    }

    @GetMapping("/melhores")
    public List<Aluno> melhores(){
        return alunos.stream().filter(aluno -> aluno.getMedia() > 9.5).collect(Collectors.toList());
    }
}
