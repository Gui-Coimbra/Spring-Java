package sptech.school.guilherme.produto;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("produtos")
public class ProdutoController {
    List<Produto> produtos = new ArrayList<>();
    int apoio = 1;

    @GetMapping
    public List<Produto> listar(){
        return produtos;
    }

    @PostMapping
    public Produto cadastrar(@RequestBody Produto produto){
        produtos.add(produto);
        produto.setId(apoio);
        apoio++;
        return produto;
    }

    @GetMapping("/{indice}")
    public Produto retornar(@PathVariable int indice){
        if(indice < produtos.size()){
            return produtos.get(indice);
        }else{
            return null;
        }
    }

//    @GetMapping("/promocao")
//    public List<Produto> promocao(){
//        List<Produto> promocionais = new ArrayList<>();
//        for(Produto produto : produtos){
//            if(produto.isPromocao()){
//                promocionais.add(produto);
//            }
//        }
//        return promocionais;
//    }

    @GetMapping("/promocao")
    public List<Produto> promocao(){
       return produtos.stream()
               .filter(produto -> produto.isPromocao())
               .collect(Collectors.toList());
    }

//    @PutMapping("/{id}")
//    public Produto atualizar(@PathVariable int id,
//                   @RequestBody Produto novoProduto){
//        for(Produto produto : produtos){
//            if(produto.getId() == id){
//                produtos.set(produtos.indexOf(produto), novoProduto);
//                return novoProduto;
//            }
//        }
//        return null;
//    }

    @PutMapping("/{id}")
    public Produto atualizar(@PathVariable int id,
                             @RequestBody Produto novoProduto){
        int i = 0;
        for(Produto produto : produtos){
            if(produto.getId() == id){
                produtos.set(i, novoProduto);
                return novoProduto;
            }
            i++;
        }
        return null;
    }
}
