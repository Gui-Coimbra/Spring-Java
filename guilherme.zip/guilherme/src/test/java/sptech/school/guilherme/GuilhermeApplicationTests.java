package sptech.school.guilherme;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GuilhermeApplicationTests {

	@Test
	void contextLoads() {
	}

}
