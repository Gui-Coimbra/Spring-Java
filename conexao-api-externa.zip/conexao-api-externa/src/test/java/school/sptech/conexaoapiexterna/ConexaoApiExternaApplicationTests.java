package school.sptech.conexaoapiexterna;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConexaoApiExternaApplicationTests {

	@Test
	void contextLoads() {
	}

}
