package school.sptech.conexaoapiexterna.controller;


import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import school.sptech.conexaoapiexterna.dto.MusicaConsultaDto;
import school.sptech.conexaoapiexterna.dto.MusicaCriacaoDto;
import school.sptech.conexaoapiexterna.service.MusicaService;

import java.util.List;

@RestController
@RequestMapping("/musicas")
@RequiredArgsConstructor
public class MusicaController {

    private final MusicaService musicaService;

    @GetMapping
    public ResponseEntity<List<MusicaConsultaDto>> listar() {
        List<MusicaConsultaDto> musicas = musicaService.listar();

        if (musicas.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(musicas);
    }

    @PostMapping
    public ResponseEntity<MusicaConsultaDto> criar(
            @RequestBody MusicaCriacaoDto musicaCriacaoDto) {

        return ResponseEntity.ok(musicaService.criar(musicaCriacaoDto));
    }

    @GetMapping("/{id}")
    public ResponseEntity<MusicaConsultaDto> buscarPorId(
            @PathVariable String id) {
        return ResponseEntity.ok(musicaService.buscaPorId(id));
    }
}
