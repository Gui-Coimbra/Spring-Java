package school.sptech.conexaoapiexterna.service;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import school.sptech.conexaoapiexterna.dto.MusicaConsultaDto;
import school.sptech.conexaoapiexterna.dto.MusicaCriacaoDto;
import school.sptech.conexaoapiexterna.integration.MusicaClient;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MusicaService {

    private final MusicaClient musicaClient;

    public List<MusicaConsultaDto> listar() {
        return musicaClient.listar();
    }

    public MusicaConsultaDto criar(MusicaCriacaoDto musicaCriacaoDto) {
        ResponseEntity<MusicaConsultaDto> resposta =
                musicaClient.criar(musicaCriacaoDto);

        if (resposta.getStatusCode().equals(HttpStatus.BAD_REQUEST)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
        }

        return resposta.getBody();
    }

    public MusicaConsultaDto buscaPorId(String id) {
        try {
            // Caso essa linha dê 500 na hora da requisição
            ResponseEntity<MusicaConsultaDto> resposta =
                    musicaClient.buscaPorId(id);

            if (resposta.getStatusCode().equals(HttpStatus.NOT_FOUND)) {
                // utilizando valueOf para diferenciar e mostrar outras maneiras.
                throw new ResponseStatusException(HttpStatus.valueOf(404));
            }

            return resposta.getBody();

        } catch (Exception e) {
            // Caso 500, retorna 422 (Unprocessable Entity)
            throw new ResponseStatusException(HttpStatus.valueOf(422));
        }
    }
}
