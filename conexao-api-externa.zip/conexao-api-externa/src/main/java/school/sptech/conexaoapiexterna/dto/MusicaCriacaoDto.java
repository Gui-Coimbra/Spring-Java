package school.sptech.conexaoapiexterna.dto;

import lombok.Data;

@Data
public class MusicaCriacaoDto {

    private String nome;
    private String artista;
    private String genero;
    private String dataLancamento;
}
