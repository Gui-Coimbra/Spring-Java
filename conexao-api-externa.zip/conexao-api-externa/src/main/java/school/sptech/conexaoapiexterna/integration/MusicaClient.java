package school.sptech.conexaoapiexterna.integration;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import school.sptech.conexaoapiexterna.dto.MusicaConsultaDto;
import school.sptech.conexaoapiexterna.dto.MusicaCriacaoDto;

import java.util.List;

@FeignClient(name = "sua-api",
        url = "sua-url")
public interface MusicaClient {

    @GetMapping
    List<MusicaConsultaDto> listar();

    @PostMapping
    ResponseEntity<MusicaConsultaDto> criar(
            @RequestBody MusicaCriacaoDto musicaCriacaoDto);

    @GetMapping("/{id}")
    ResponseEntity<MusicaConsultaDto> buscaPorId(@PathVariable String id);
}
