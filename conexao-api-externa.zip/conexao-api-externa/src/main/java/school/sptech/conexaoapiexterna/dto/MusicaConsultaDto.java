package school.sptech.conexaoapiexterna.dto;

import lombok.Data;

@Data
public class MusicaConsultaDto {

    private String id;
    private String nome;
    private String artista;
    private String genero;
    private String dataLancamento;
}
