package school.sptech.primeiraapi;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/calculadoras")
public class CalculadoraController {

      /*
	  Aqui a URI contém PATH VARIABLES
	  Ou seja, partes dinâmicas que influenciam no resultado
	  Os path params aqui são numero1 e numero2.
	  Eles foram associados aos parâmetros de mesmo nome
	  do método devido às anotações @PathVariable em cada parâmetro
 */
    @GetMapping("/somar/{numero1}/{numero2}")
    public String somar(
            @PathVariable int numero1,
            @PathVariable int numero2
    ) {
        return String.format("Resultado: %d", (numero1 + numero2));
    }

}
