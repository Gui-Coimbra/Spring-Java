package school.sptech.primeiraapi;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//@Controller // para servir páginas

/*
	@RestController -> Isto é uma ANOTAÇÃO (annotation)
	Esta anotação indica que a classe será uma
	Controladora REST. Ou seja, Ela poderá ter CHAMADAS da API
 */
@RestController
@RequestMapping("/frases") // especifica um padrão para as chamadas da controladora (plural sempre)
public class FrasesController {


/*
	  A anotação @GetMapping transforma o método anotado
  	em uma CHAMADA DA API REST do projeto
 */
    @GetMapping
    public String hello(){
        return "Olá Mundo";
    }

    @GetMapping("/bom-dia") // podemos especificar uma URI, o endpoint acima atende na URI: /frases
    public String bomDia(){
        return "Bom dia flor do dia";
    }

    @GetMapping("/boa-tarde")
    public String boaTarde(){
        return "Café ???";
    }

    @GetMapping("/boa-noite")
    public String boaNoite(){
        return "Bom descanso (saia do Discord)";
    }
}
